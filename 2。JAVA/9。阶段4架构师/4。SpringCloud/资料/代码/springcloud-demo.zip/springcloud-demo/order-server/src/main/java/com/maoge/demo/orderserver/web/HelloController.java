package com.maoge.demo.orderserver.web;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope //标记的类是一个延迟加载对象, 在访问的时候创建, 并且刷新env环境的时候会清除该对象
public class HelloController {

    @Value("${limitNum}")  //
    private String limitNum;

    @RequestMapping("hello")
    public String hello(){
        System.out.println("用户的限购数量:"+limitNum);
        return limitNum;
    }

}
