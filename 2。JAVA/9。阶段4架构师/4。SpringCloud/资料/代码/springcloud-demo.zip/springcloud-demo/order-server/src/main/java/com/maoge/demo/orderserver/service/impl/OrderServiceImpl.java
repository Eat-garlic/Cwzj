package com.maoge.demo.orderserver.service.impl;

import com.maoge.demo.domain.Product;
import com.maoge.demo.feign.ProductFeignApi;
import com.maoge.demo.orderserver.domain.Order;
import com.maoge.demo.orderserver.service.IOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

@Service
@Slf4j
public class OrderServiceImpl implements IOrderService {
    //ProductFeignApi 类型的Bean对象 跟据ProductFeignApi 接口创建动态代理对象jdk动态代理
    @Autowired
    private ProductFeignApi productFeignApi;
    @Override
    public Order save(Long userId, Long productId) {
        log.info("发起商品服务远程调用");
        Product product = productFeignApi.find(productId);//远程获取
        Order order = new Order();
        order.setOrderNo(UUID.randomUUID().toString().replace("-",""));
        order.setCreateTime(new Date());
        order.setUserId(userId);
        order.setProductName(product.getName());
        order.setProductPrice(product.getPrice());
        log.info("执行保存订单操作");
        return order;
    }
}