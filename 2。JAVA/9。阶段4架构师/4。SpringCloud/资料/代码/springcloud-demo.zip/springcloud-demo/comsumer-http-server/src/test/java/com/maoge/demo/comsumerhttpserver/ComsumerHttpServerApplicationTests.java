package com.maoge.demo.comsumerhttpserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComsumerHttpServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
