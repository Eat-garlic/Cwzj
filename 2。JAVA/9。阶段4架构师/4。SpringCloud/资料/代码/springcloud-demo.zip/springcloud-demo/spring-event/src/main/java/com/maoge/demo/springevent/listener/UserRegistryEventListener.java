package com.maoge.demo.springevent.listener;

import com.maoge.demo.springevent.event.UserRegistryEvent;
import org.springframework.context.ApplicationListener;

//事件监听器
//@Component
public class UserRegistryEventListener implements ApplicationListener<UserRegistryEvent> {
    @Override
    public void onApplicationEvent(UserRegistryEvent event) {
        //获取事件对应的信息
        System.out.println("用户信息:"+event.getUserBean());
        System.out.println("给指定用户发送短息");
        System.out.printf("%s",event.getSource());
    }
}
