package com.maoge.demo.springevent.domain;

import lombok.Data;

@Data
public class UserBean {
    private Long id;
    private String name;
}
