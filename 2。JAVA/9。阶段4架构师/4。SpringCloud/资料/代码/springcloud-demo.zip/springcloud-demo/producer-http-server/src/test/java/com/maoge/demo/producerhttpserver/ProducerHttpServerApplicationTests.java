package com.maoge.demo.producerhttpserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerHttpServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
