package com.maoge.demo.producerhttpserver;

import com.maoge.demo.producerhttpserver.steam.ISenderService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableBinding(ISenderService.class)
public class ProducerHttpServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProducerHttpServerApplication.class, args);
    }
    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }
}
